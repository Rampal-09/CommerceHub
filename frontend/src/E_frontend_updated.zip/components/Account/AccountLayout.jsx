import React from "react";
import { Outlet, Navigate, useLocation } from "react-router-dom";
import { UserCheck } from "lucide-react";
import Sidebar from "./Sidebar";
import Breadcrumb from "./Breadcrumb";
import { useProfile } from "../../hooks/useProfile";
import { useAuth } from "../../context/authContext";

/**
 * Account Section Main Responsive Layout Wrapper
 */
export const AccountLayout = () => {
  const { user } = useAuth();
  const { profile } = useProfile();
  const location = useLocation();

  if (user?.role === "admin" && location.pathname !== "/account/change-password") {
    return <Navigate to="/admin/dashboard" replace />;
  }

  return (
    <div className="min-h-screen bg-slate-50/60 font-sans text-slate-800 pb-16">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white py-10 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto space-y-3">
          <Breadcrumb items={[{ label: "My Account" }]} />

          <div className="flex items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight flex items-center gap-3">
                <UserCheck className="w-8 h-8 text-indigo-400" /> Account Settings
              </h1>
              <p className="text-sm text-slate-300">
                Manage your personal profile, addresses, orders, and account security.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Sidebar userProfile={profile} />
          </div>

          {/* Subpage Outlet Content */}
          <div className="lg:col-span-3 min-w-0">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountLayout;
